
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import net.miginfocom.swing.MigLayout;
import javax.swing.SwingConstants;

@SuppressWarnings("serial")
public class LapTimer extends JFrame {

	private Font counterFont = new Font("Arial", Font.BOLD, 20);
	private Font totalFont = new Font("Arial", Font.PLAIN, 14);

	private JLabel lapLabel = new JLabel("Seconds running:");
	private JTextField lapField = new JTextField(15);
	private JLabel totalLabel = new JLabel("Total seconds:");
	private JTextField totalField = new JTextField(15);
	private JTextArea displayDataField = new JTextArea();//JTextArea that will display data in JOptionPane

	private JButton startButton = new JButton("START");
	private JButton lapButton = new JButton("LAP");
	private JButton stopButton = new JButton("STOP");

	// The text area and the scroll pane in which it resides
	private JTextArea display;

	private JScrollPane myPane;

	// These represent the menus
	private JMenuItem saveData = new JMenuItem("Save data", KeyEvent.VK_S);
	private JMenuItem displayData = new JMenuItem("Display data", KeyEvent.VK_D);

	private JMenu options = new JMenu("Options");

	private JMenuBar menuBar = new JMenuBar();

	private boolean started;

	private float totalSeconds = (float) 0.0;
	private float lapSeconds = (float) 0.0;

	private int lapCounter = 1;

	private LapTimerThread lapThread;

	private Session currentSession;

	private final JLabel lblLapTimeGoal = new JLabel("Lap time goal:");
	private final JTextField goalTextField = new JTextField();
	private final JPanel SetTimePanel = new JPanel();
	private final JLabel lblSeconds = new JLabel("seconds");

	private String[] goal_message = { "GOAL REACHED", "GOAL NOT REACHED" };

	File currentFile;

	float goal;

	public LapTimer() {

		setTitle("Lap Timer Application");

		MigLayout layout = new MigLayout("fillx");
		JPanel panel = new JPanel(layout);
		getContentPane().add(panel);

		options.add(saveData);
		options.add(displayData);
		menuBar.add(options);

		this.setJMenuBar(menuBar);

		MigLayout centralLayout = new MigLayout("fillx");

		JPanel centralPanel = new JPanel(centralLayout);

		GridLayout timeLayout = new GridLayout(0, 2);

		JPanel timePanel = new JPanel(timeLayout);

		lapField.setEditable(false);
		lapField.setFont(counterFont);
		lapField.setText("00:00:00.0");

		totalField.setEditable(false);
		totalField.setFont(totalFont);
		totalField.setText("00:00:00.0");
		timePanel.add(lblLapTimeGoal);

		timePanel.add(SetTimePanel);
		goalTextField.setText("60");
		goalTextField.setColumns(10);
		SetTimePanel.add(goalTextField);
		SetTimePanel.add(lblSeconds);

		// Setting the alignments of the components
		lblLapTimeGoal.setHorizontalAlignment(SwingConstants.RIGHT);
		goalTextField.setHorizontalAlignment(SwingConstants.CENTER);
		totalLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lapLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lapField.setHorizontalAlignment(JTextField.CENTER);
		totalField.setHorizontalAlignment(JTextField.CENTER);

		timePanel.add(lapLabel);
		timePanel.add(lapField);
		timePanel.add(totalLabel);
		timePanel.add(totalField);

		centralPanel.add(timePanel, "wrap");

		GridLayout buttonLayout = new GridLayout(1, 3);

		JPanel buttonPanel = new JPanel(buttonLayout);

		buttonPanel.add(startButton);
		buttonPanel.add(lapButton);
		buttonPanel.add(stopButton);

		centralPanel.add(buttonPanel, "spanx, growx, wrap");

		panel.add(centralPanel, "wrap");

		display = new JTextArea(100, 150);
		display.setMargin(new Insets(5, 5, 5, 5));
		display.setEditable(false);
		myPane = new JScrollPane(display, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		panel.add(myPane, "alignybottom, h 100:320, wrap");

		// Initial state of system
		started = false;
		currentSession = new Session();

		// Allowing interface to be displayed
		setSize(400, 500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		/*
		 * This method should allow the user to save data to a file called
		 * textData.txt
		 */
		saveData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				/* Insert code here */
				if (currentFile != null && currentFile.exists()) {//check if file exists in file system
					int result = JOptionPane.showConfirmDialog(null,
							"This will overwrite the existing file.\n Are you sure you want to do this?");
					if (result == 0) {//if they want to overwrite, overwrite current data in the file 
						try {
							writeDataFile(currentFile);
						} catch (IOException ex) {
							JOptionPane.showMessageDialog(null, "I/O Exception\n " + ex.toString(), "Error Message",
									JOptionPane.ERROR_MESSAGE);
						}
					}
				}
				// Otherwise we need to specify the name to use for this file
				else {
					JOptionPane.showMessageDialog(null, "You must enter a name for this file.\n", "Save File",
							JOptionPane.PLAIN_MESSAGE);
					// Ask user to specify file name (remember user can type in
					// new file name in file chooser)
					JFileChooser fc = new JFileChooser();
					fc.setCurrentDirectory(new File(System.getProperty("user.dir")));//open in correct directory
					int returnVal = fc.showSaveDialog(null);//show file chooser
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						currentFile = fc.getSelectedFile();
						if (currentFile.exists()) {//check if file already exists
							int result = JOptionPane.showConfirmDialog(null,
									"This will overwrite the existing file.\n Are you sure you want to do this?");
							if (result == 0) {
								try {
									writeDataFile(currentFile);//overwrite data in file
								} catch (IOException ex) {
									JOptionPane.showMessageDialog(null, "I/O Exception\n " + ex.toString(),
											"Error Message", JOptionPane.ERROR_MESSAGE);
								}
							}
						} else {//if it doesnt extist
							try {
								writeDataFile(currentFile);//write data into file
							} catch (IOException ex) {
								JOptionPane.showMessageDialog(null, "I/O Exception\n " + ex.toString(), "Error Message",
										JOptionPane.ERROR_MESSAGE);
							}
						}
					}
				}
			}
		});

		/*
		 * This method should retrieve the contents of a file representing a
		 * previous report using a JFileChooser. The result should be displayed
		 * as the contents of a dialog object.
		 */
		displayData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				fc.setCurrentDirectory(new File(System.getProperty("user.dir")));//open in correct directory
				int returnVal = fc.showOpenDialog(LapTimer.this);//show file chooser
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();

					try {

						displayDataField.append(readDataFile(file));//call readDataFile method and append JTextArea with string it returns
						JOptionPane.showMessageDialog(null, displayDataField, "information", 
								JOptionPane.INFORMATION_MESSAGE);//display JTextArea in pop-up 

					} catch (IOException ex) {
						JOptionPane.showMessageDialog(LapTimer.this, "I/O Exception\n " + ex.toString(),
								"Error Message", JOptionPane.ERROR_MESSAGE);
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}
			}
		});

		/*
		 * This method should check to see if the application is already
		 * running, and if not, launch a LapTimerThread object, but if there is
		 * another session already under way, it should ask the user whether
		 * they want to restart - if they do then the existing thread and
		 * session should be reset. The lap counter should be set to 1 and a new
		 * Session object should be created. A new LapTimerThread object should
		 * be created with totalSeconds set to 0.0 and the display area should
		 * be cleared. When the new thread is started, make sure the goal
		 * textField is disabled
		 */
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// surround in a try-catch to make sure laptime goal is a float,
				// timer will not start if not
				try {
					goal = Float.parseFloat(goalTextField.getText());
					if (started == true) {// Check if thread is already running
						int result = JOptionPane.showConfirmDialog(null, "Aleady running, restart?");// if running ask if they want to restart
						if (result == JOptionPane.YES_OPTION) {// if yes
							lapThread.stop();// stop the thread
							totalSeconds = (float) 0.0;// reset total seconds to 0
							display.setText("");// clear the text field
							lapCounter = 1;// reset lap counter to 1
							currentSession = new Session();// create a new session
							lapThread = new LapTimerThread(LapTimer.this, LapTimer.this.totalSeconds);// create a new lap thread
							Thread thrd = new Thread(lapThread);
							thrd.start();// start the thread
						}//if no do nothing, let thread continue running
					} else { //if its not running: the same as if it is and set started = true and no need to stop the thread 
						display.setText("");
						totalSeconds = (float) 0.0;
						lapCounter = 1;
						currentSession = new Session();
						lapThread = new LapTimerThread(LapTimer.this, LapTimer.this.totalSeconds);
						Thread thrd = new Thread(lapThread);
						thrd.start();
						started = true;
					}
					goalTextField.setEditable(false);
				} catch (RuntimeException ex) {
					JOptionPane.showMessageDialog(null, "Laptime goal must be a number");
				}
			}
		});

		/*
		 * This method should only work if a session has been started. Once
		 * started, clicking the Lap button should cause the length of the
		 * current lap to be retrieved and used to create a new Lap object which
		 * is added to the session collection. The old LapTimerThread object
		 * should be stopped and a new thread should be started with the updated
		 * value of total seconds. The lap number and time should be added to
		 * the display area. The message saying if the goal was reached also
		 * need to be added
		 */
		lapButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				/* Insert code here */
				if (started == true) {//check if timer is running
					Lap lap = new Lap(lapCounter, lapThread.getLapSeconds());//create a new lap object
					currentSession.addLap(lap);//add the lap to the vector
					lapThread.stop();
					lapCounter++;
					//display lap id and time
					display.append("\n" + lap.display());
					display.append("	");
					display.append(convertToHMSString(lap.getLapTime()));
					display.append("	");
					//compare lap seconds to the goal time and display either reached or not reached
					if (lapThread.getLapSeconds() < goal)
						display.append(goal_message[0]);
					else
						display.append(goal_message[1]);
					totalSeconds = totalSeconds + lapThread.getLapSeconds();//update total seconds
					lapThread = new LapTimerThread(LapTimer.this, totalSeconds);//create a new lap timer thread
					Thread thrd = new Thread(lapThread);
					thrd.start();
				} else //if timer is not running, you cant create a lap, display error message
					JOptionPane.showMessageDialog(null, "The timer is not running", "Error Message",
							JOptionPane.ERROR_MESSAGE);
			}
		});

		/*
		 * This method should have most of the same functionality as the Lap
		 * button's action listener, except that a new LapTimerThread object is
		 * NOT started. In addition, the total time for all the laps should be
		 * calculated and displayed in the text area, along with the average lap
		 * time and the numbers and times of the fastest and slowest laps.
		 */
		stopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				/* Insert code here */
				if (started == true) {//check if the thread is started 
					Lap lap = new Lap(lapCounter, lapThread.getLapSeconds());//stop button creates the final lap
					currentSession.addLap(lap);
					lapThread.stop();
					lapCounter++;
					display.append("\n" + lap.display());
					display.append("	");
					display.append(convertToHMSString(lap.getLapTime()));
					display.append("	");
					if (lapThread.getLapSeconds() < goal)
						display.append(goal_message[0]);
					else
						display.append(goal_message[1]);
					totalSeconds = totalSeconds + lapThread.getLapSeconds();
					display.append("\n");
					
					display.append("\nStopped at : " + convertToHMSString(totalSeconds));//display time timer was stopped at
					lapThread.stop();
					display.append("\nAverage : " + convertToHMSString(currentSession.calculateAverageTime()));
					display.append("\n");
					display.append("\nFastest lap : " + currentSession.getFastestLap().display() + " "
							+ convertToHMSString(((currentSession.getFastestLap().getLapTime()))));
					display.append("\nSlowest lap : " + currentSession.getSlowestLap().display() + " "
							+ convertToHMSString(currentSession.getSlowestLap().getLapTime()));
					goalTextField.setEditable(true);
				} else
					JOptionPane.showMessageDialog(null, "The timer is not running", "Error Message",
							JOptionPane.ERROR_MESSAGE);
				started = false;
			}
		});

	}

	/*
	 * These two methods are used by the LapTimerThread to update the values
	 * displayed in the two text fields. Each value is formatted as a hh:mm:ss.S
	 * string by calling the convertToHMSString method below/.
	 */

	public void updateLapDisplay(float value) {

		lapField.setText(convertToHMSString(value));

	}

	public void updateTotalDisplay(float value) {

		totalField.setText(convertToHMSString(value));

	}

	/*
	 * These methods are here to help access the goaltextField in the GUI
	 */

	public String getGoalValue() {
		return goalTextField.getText();
	}

	public void EnableGoalEditing(boolean makeEditable) {
		goalTextField.setEditable(makeEditable);
	}

	public void setTextArea(String str) {
		display.setText(str);
	}

	private String convertToHMSString(float seconds) {
		long msecs, secs, mins, hrs;
		// String to be displayed
		String returnString = "";

		// Split time into its components

		long secondsAsLong = (long) (seconds * 10);

		msecs = secondsAsLong % 10;
		secs = (secondsAsLong / 10) % 60;
		mins = ((secondsAsLong / 10) / 60) % 60;
		hrs = ((secondsAsLong / 10) / 60) / 60;

		// Insert 0 to ensure each component has two digits
		if (hrs < 10) {
			returnString = returnString + "0" + hrs;
		} else
			returnString = returnString + hrs;
		returnString = returnString + ":";

		if (mins < 10) {
			returnString = returnString + "0" + mins;
		} else
			returnString = returnString + mins;
		returnString = returnString + ":";

		if (secs < 10) {
			returnString = returnString + "0" + secs;
		} else
			returnString = returnString + secs;

		returnString = returnString + "." + msecs;

		return returnString;

	}

	/*
	 * These methods will be used by the action listeners attached to the two
	 * menu items.
	 */

	public synchronized void writeDataFile(File f) throws IOException, FileNotFoundException {

		ObjectOutputStream out = null;//create a new object output stream
		try {
			out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
			out.writeObject(display.getText());//retrieve text from text area and write into the object output stream
			// Closing the output stream
		} finally {
			out.close();
		}
	}

	public synchronized String readDataFile(File f) throws IOException, ClassNotFoundException {
		ObjectInputStream in = null;//create a new object input stream
		Object obj = new Object();//create a generic object
		try {
			in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(f)));//read the file into the input stream

			obj = in.readObject();//read the input stream into the object

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			in.close();
		}
		String result = new String(obj.toString());//create a string version of the object
		return result;
	}

	public static void main(String[] args) {

		LapTimer timer = new LapTimer();
		timer.setVisible(true);

	}

}