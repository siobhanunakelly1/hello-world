

import java.io.Serializable;
import java.util.Vector;


public class Session {

	Vector<Lap> laps = new Vector<Lap>();
	
	public Session() {

		laps = new Vector<Lap>();

	}
	
	public void addLap(Lap l) {
		
		laps.add(l);
		
	}
	
	public float calculateAverageTime() {
		
		/*Create sum and average variables, and set sum = 0
		 *For loop iterates through each lap in the vector and adds each laps time on to the sum
		 *Divide the sum by the number of laps
		 */
		float sum = 0;
		float avg;
		for(Lap lap : laps){
			sum = sum + lap.getLapTime();
		}
		avg = sum/laps.size();
		return avg;
	}
	
	
	public Lap getFastestLap() {
		
		/*
		 * Create a lap object called fastest
		 * Assume first lap is fastest to start with
		 * Loop through the laps and compare each's time with the fastest
		 * If time is smaller set that lap to be the fastest
		 */
		Lap fastest = laps.get(0);
		for(Lap lap : laps){
			if(lap.getLapTime() < fastest.getLapTime()){
				fastest = lap;
			}
		}
		return fastest;   
		
	}
	
	public Lap getSlowestLap() {
		
		/* 
		 *  Similar to fastest
		 */
		Lap slowest = laps.get(0);
		for(Lap lap : laps){
			if(lap.getLapTime() > slowest.getLapTime()){
				slowest = lap;
			}
		}
		return slowest;   	
	}
}
